import React, { useState, useEffect, useRef } from "react";

const CHAT_KEY = "dishcovery_chat_history";

function readChat() {
  try {
    return JSON.parse(localStorage.getItem(CHAT_KEY)) || [];
  } catch {
    return [];
  }
}

function writeChat(history) {
  localStorage.setItem(CHAT_KEY, JSON.stringify(history));
}

// 🔹 Function that talks to OpenRouter API
async function askRecipeAssistant(messages) {
  const API_KEY = import.meta.env.VITE_OPENROUTER_API_KEY;
  if (!API_KEY) throw new Error("Missing VITE_OPENROUTER_API_KEY in .env");

  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: messages,
    }),
  });

  const data = await res.json();
  return (
    data?.choices?.[0]?.message?.content ||
    "Sorry, I couldn’t find a recipe idea for that."
  );
}

// 🔹 Helper: convert **text** to formatted HTML
function formatMessage(text) {
  if (!text) return "";
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>") // **bold**
    .replace(/\n/g, "<br>") // new lines
    .replace(/[-*]\s/g, "• "); // bullets
}

export default function Chatbot() {
  const [history, setHistory] = useState(readChat());
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    writeChat(history);
  }, [history]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history, loading]);

  async function send() {
    if (!input.trim() || loading) return;

    const userMsg = { role: "user", content: input.trim() };
    setHistory((h) => [...h, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const reply = await askRecipeAssistant([
        { role: "system", content: "You are a helpful cooking assistant. Only answer about recipes. Format clearly with steps and bullet points." },
        ...history,
        userMsg,
      ]);

      setHistory((h) => [...h, { role: "assistant", content: reply }]);
    } catch (e) {
      setHistory((h) => [...h, { role: "assistant", content: "Error: " + e.message }]);
    }

    setLoading(false);
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>🤖 Recipe Chatbot</h2>

      <div style={styles.chatbox}>
        {history.map((msg, i) => (
          <div
            key={i}
            style={{
              ...styles.message,
              background: msg.role === "user" ? "#383e56" : "#1a1a1a",
              alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
              color: msg.role === "user" ? "#fff" : "#e0e0e0",
            }}
            dangerouslySetInnerHTML={{
              __html: `<strong>${msg.role === "user" ? "You" : "Bot"}:</strong> ${formatMessage(
                msg.content
              )}`,
            }}
          />
        ))}
        {loading && <div style={styles.loading}>🍳 Thinking...</div>}
        <div ref={scrollRef}></div>
      </div>

      <div style={styles.inputArea}>
        <input
          style={styles.input}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about recipes..."
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
        <button style={styles.button} onClick={send}>
          Send
        </button>
      </div>

      {!import.meta.env.VITE_OPENROUTER_API_KEY && (
        <p style={{ color: "red", marginTop: 10 }}>
          ⚠️ Missing API key — please add VITE_OPENROUTER_API_KEY in .env file.
        </p>
      )}
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: 20,
    color: "#fff",
  },
  title: { fontSize: 24, marginBottom: 10 },
  chatbox: {
    width: "80%",
    maxWidth: 750,
    height: 450,
    overflowY: "auto",
    background: "#0d0d0d",
    padding: 20,
    borderRadius: 12,
    marginBottom: 15,
    boxShadow: "0 0 15px rgba(255,255,255,0.05)",
  },
  message: {
    marginBottom: 15,
    padding: 12,
    borderRadius: 10,
    maxWidth: "85%",
    lineHeight: 1.5,
    whiteSpace: "pre-wrap",
    fontSize: 15,
  },
  inputArea: { display: "flex", width: "80%", maxWidth: 700 },
  input: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    border: "1px solid #444",
    outline: "none",
    fontSize: 15,
    backgroundColor: "#1c1c1c",
    color: "#fff",
  },
  button: {
    marginLeft: 10,
    padding: "12px 24px",
    borderRadius: 8,
    border: "none",
    background: "linear-gradient(45deg, #ff7f00, #ff9d47)",
    color: "white",
    cursor: "pointer",
    fontWeight: "bold",
  },
  loading: {
    color: "#aaa",
    fontStyle: "italic",
    marginTop: 10,
  },
};
