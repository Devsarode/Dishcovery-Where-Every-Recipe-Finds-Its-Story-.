package com.example.dishcovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DishcoveryApplication {
    public static void main(String[] args) {
        SpringApplication.run(DishcoveryApplication.class, args);
    }
}
